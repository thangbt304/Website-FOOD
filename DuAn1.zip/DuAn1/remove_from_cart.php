<?php
session_start();

if (isset($_GET['masp'])) {
    $masp = $_GET['masp'];
    
    if (isset($_SESSION['cart'][$masp])) {
        unset($_SESSION['cart'][$masp]);
    }
}

header('Location: giohang.php');
exit();
?>
