<?php

require_once('config.php');
session_start();
// Kiểm tra xem người dùng đã đăng nhập chưa
if (isset($_SESSION['matk'])) {
    $matk = $_SESSION['matk'];
    // Sử dụng $matk để thực hiện các thao tác liên quan đến tài khoản
} else {
    // Người dùng chưa đăng nhập, thực hiện các hành động phù hợp
}
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

$cart = $_SESSION['cart'];
$totalPrice = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['quantity'] as $masp => $quantity) {
        if ($quantity == 0) {
            unset($_SESSION['cart'][$masp]);
        } else {
            $_SESSION['cart'][$masp] = $quantity;
        }
    }
    header('Location: giohang.php');
    exit();
}
require('config.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$role = isset($_SESSION['role']) ? $_SESSION['role'] : ''; 
$user = isset($_SESSION['tentk']) ? $_SESSION['tentk'] : '';
if(isset($_SESSION['cart'])){
    $giohang_count = count($_SESSION['cart']);
}else{
    $giohang_count = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>foob</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"rel="stylesheet">     <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="./style2.css">

    <style>
        /* width */
        ::-webkit-scrollbar {
            width: 7px;
            background: #17171900;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            box-shadow: inset 0 0 0px rgba(128, 128, 128, 0); 
  
        }
 
        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #e5c591; 
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: rgb(255, 213, 2); 
        }
        a.Ten{
            color: #e5c591;
        }
        a.Ten::after{
            content: "";
            position: absolute;
            width: 110%;
            height: 1.5px;
            bottom: -8px;  
            right: -5%;
            background-color: #e5c591;
            visibility: visible;
        }
        a.Ten:before{
            content: "";
            position: absolute;
            width: 110%;
            height: 1.5px;
            bottom: -12px;  
            right: -5%;
            background-color: #e5c591;
            visibility: visible;}
            .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .cart {
            background: #e5c59100;
            padding: 20px;
            margin-top: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            color: #e5c591;
        }

        table {
            border: none;
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {

            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }

        table th {
            background-color:#878582;
        }

        .cart-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 5px;
        }

        .quantity-input {
            width: 50px;
            text-align: center;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .remove-link {
            color: red;
            text-decoration: none;
        }

        .total-price {
            text-align: right;
            font-size: 1.2em;
            margin-top: 20px;
        }

        .btn {
            display: inline-block;
            background: #333;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn:hover {
            background: #555;
        }

        .btn-update {
            background: #007BFF;
            margin-top: 20px;
        }

        .btn-update:hover {
            background: #0056b3;
        }
        button{
            width: 100px;
            height: 30px;
            transform: translateX(0px);
        }
    </style>
</head>
<body>
    <header>
        <div class="len" >
            <a href="#dau">
                <span class="material-symbols-outlined">
                arrow_upward_alt
                </span>
            </a>
        </div>

        <div class="colo-black"></div>

        <div class="thongTinLienHe" id="dau"> 
            <div class="thongTinLienHe-right">
                <p>PHONE: +07 557 911 231</p>
                <p>EMAIL: TTHANG@GMAIL.COM</p>
            </div>

            <div class="thongTinLienHe-left">
                <p>GIFT CARD</p>
                <p>TRACK ORDER</p>
                <p>LANGUAGE</p>
            </div>

        </div>  


        <nav>
            <div class="logo">

                <img src="./imge/Logo.jpg" alt="">
            </div>
            <div class="bangDieuKhien">
                <a href="./index.php">HOME</a>
                <a href="./about.php">ABOUT</a>
                <a href="./danhsach.php">PRODUCT</a>
                <a href="#" class="Ten">CART
                <b style="color:white; margin-left:3px; margin-top:2px;">(<?php echo $giohang_count; ?>)</b>
                </a>
                <a href="./lienhe.php">CONTACT</a>
            </div>

            <div class="thanhIcon">
                <a href="#" class="close" id="click_menu">
                    <span class="material-icons-sharp" id="menu_btn">
                        menu
                    </span>                     
                </a>
               
                <a href="./sign_in.php" style="display: flex; flex-direction: column;">
                <span style="font-size: 30px;" class="material-symbols-outlined">
                account_circle
                </span>      
                <?php if (isset($_SESSION['tentk'])) { ?>
                    <b style=" position:relative; top:-4px; vertical-align: middle; font-weight:400;"><?php echo $user; ?></b>
                <?php } ?>                             
                </a>
            </div>

        </nav>


        <div class="menudoc" id="menu">
            <div>
                <span class="material-icons-sharp" id="xoa"> highlight_off</span>
            </div>
            
            <a href="./index.html"><span class="material-icons-sharp" class="menu_icon"> home </span> </a>
            <a href="./about.html"><span class="material-icons-sharp" class="menu_icon"> photo library </span></a>
            <a href="./sanpham.html"><span class="material-icons-sharp" class="menu_icon"> sell </span></a> 
            <a href="./danhmuc.html"><span class="material-icons-sharp" class="menu_icon"> lists </span> </a>
            <a href="./lienhe.html"><span class="material-icons-sharp" class="menu_icon"> settings </span></a> 
        </div>


    </header>   

    <div class="main0"></div>

    <main>
        <div class="main_conten">
            <p class="comen1">PLEASE CONTACT US</p>
                <div class="square">
                    <div class="square-min"></div>
                    <div class="square-min"></div>
                    <div class="square-min"></div>
                </div> <br>
            <h1 style="color: #f4f4f4;">Your Shopping Cart</h1>  <br><br><br>
        </div>
        <div class="container">
        <div class="cart">
            <?php if (empty($cart)) { ?>
                <p>Giỏ hàng của bạn đang trống.</p>
            <?php } else { ?>
                <form action="giohang.php" method="POST">
                    <table>

                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Amount</th>
                                <th>Sum</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cart as $masp => $quantity) { 
                                $masp_escaped = mysqli_real_escape_string($connection, $masp);
                                $sql = "SELECT * FROM sanpham WHERE masp = '$masp_escaped'";
                                $result = mysqli_query($connection, $sql);
                                $product = mysqli_fetch_assoc($result);
                                $totalPrice += $product['dongia'] * $quantity;
                            ?>
                                <tr class="cart-item">
                                    <td><img src="<?php echo $product['hinhanh']; ?>" alt="<?php echo $product['tensp']; ?>"></td>
                                    <td><?php echo $product['tensp']; ?></td>
                                    <td>$<?php echo number_format($product['dongia']); ?>.00</td>
                                    <td><input type="number" name="quantity[<?php echo $masp; ?>]" value="<?php echo $quantity; ?>" class="quantity-input"></td>
                                    <td>$<?php echo number_format($product['dongia'] * $quantity); ?>.00</td>
                                    <td><a class="remove-link" href="remove_from_cart.php?masp=<?php echo $masp; ?>">Xóa</a></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    <p class="total-price">Total Sum : $<?php echo number_format($totalPrice); ?>.00</p>
                    <button class="but" type="submit" class="btn btn-update">Update</button>
                </form>
                <br>
                <a href="checkout.php" class="btn">Buy</a>
            <?php } ?>
        </div>
    </div>
        

    </main>






    <footer>
        <div class="foot-black">

        </div>
        <div class="footer-img">
            <img src="./imge/background_footer.jpg" alt="">
        </div>

        <div class="foot-conten">
            <div class="box1">
                <a href="./index.html">HOME</a>
                <a href="">ABOUT</a>
                <a href="">PRODUCT</a>
                <a href="">BLOG</a>
                <a href="">CONTACT</a>
            </div>
            <div class="box2">
                <img class="foot-menu" src="./imge/menu_food.jpg" alt="">
                <div class="box2-1"> 
                    <img class="foot-logo" src="./imge/Logo.jpg" alt="logo">
                    <p><span class="material-symbols-outlined"> location_on </span>
                        K6?/5? ,Nguyễn Phan Vinh, Sơn Trà, Đà Nẵng, VietNam, ASEA</p>

                    <p><span class="material-symbols-outlined"> account_circle</span>
                        buithethang@gmail.com</p>

                    <p><span class="material-symbols-outlined">call</span>
                        Booking Request: +77-432-654321 </p>

                    <p><span class="material-symbols-outlined"> schedule</span>
                        Open : 07:00 am - 01:00 pm </p>

                    <div class="square">
                        <div class="square-min"></div>
                        <div class="square-min"></div>
                        <div class="square-min"></div>
                    </div>

                    <h1> Get News & Offers</h1>
                    <p>Subscribe ASEA & Get <b style="color: aliceblue;">34% Off!</b> </p>

                    <div class="subscribe">
                        <span class="material-symbols-outlined" style="color: aliceblue;">
                            mail
                        </span>
                        <input class="sub-input" type="text" placeholder="Your email">
                        <p class="sup">SUBSCRIBE</p>
                    </div>
                    <p style="margin-top: 30px;">Nếu như chưa có tài khoảng hãy nhấp vào <a href="#">register?</a> </p>
                </div>
                
            </div>
            <div class="box3">
                <a href="">facebook</a>
                <a href="">TikTok</a>
                <a href="">Twitter</a>
                <a href="">Instagram</a>
                <a href="">Facebook</a>
            </div>
        </div>
    </footer>



    <script src="javascritp.js"></script>
</body>
</html>
