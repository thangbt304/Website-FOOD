<?php
session_start();
require_once('config.php');

// Kiểm tra xem giỏ hàng có tồn tại và không rỗng không
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit();
}

// Kiểm tra xem người dùng đã đăng nhập chưa
if (!isset($_SESSION['matk'])) {
    header('Location: sign_in.php');
    exit();
}

$matk = $_SESSION['matk'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $cart = $_SESSION['cart'];
    $totalPrice = 0;

    // Tính tổng tiền từ giỏ hàng
    foreach ($cart as $masp => $quantity) {
        $masp_escaped = mysqli_real_escape_string($connection, $masp);
        $sql = "SELECT * FROM sanpham WHERE masp = '$masp_escaped'";
        $result = mysqli_query($connection, $sql);
        $product = mysqli_fetch_assoc($result);
        $totalPrice += $product['dongia'] * $quantity;
    }

    // Chèn thông tin hóa đơn vào bảng hoadon với trạng thái mặc định là 'Đang xử lý'
    $sql = "INSERT INTO hoadon (tenkh, sdt, email, diachi, tongtien, matk, trangthai) 
            VALUES ('$name', '$phone', '$email', '$address', '$totalPrice', '$matk', 'Đang xử lý')";
    mysqli_query($connection, $sql);
    $hoadon_id = mysqli_insert_id($connection);

    // Chèn chi tiết hóa đơn vào bảng chitiethoadon
    foreach ($cart as $masp => $quantity) {
        $masp_escaped = mysqli_real_escape_string($connection, $masp);
        $sql = "SELECT * FROM sanpham WHERE masp = '$masp_escaped'";
        $result = mysqli_query($connection, $sql);
        $product = mysqli_fetch_assoc($result);
        $dongia = $product['dongia'];

        $sql = "INSERT INTO chitiethoadon (mahd, masp, soluong, dongia) VALUES ('$hoadon_id', '$masp', '$quantity', '$dongia')";
        mysqli_query($connection, $sql);
    }

    // Cập nhật trạng thái hóa đơn (ví dụ, chuyển sang 'Đã giao')
    

    // Xóa giỏ hàng sau khi đặt hàng
    unset($_SESSION['cart']);
    header('Location: success.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh Toán</title>
    <link rel="stylesheet" href="./styles.css"> <!-- Link đến file CSS chính nếu có -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 50%;
            margin: auto;
            overflow: hidden;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 30px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .btn {
            display: inline-block;
            background: #333;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
            cursor: pointer;
            font-size: 18px;
            border: none;
        }

        .btn:hover {
            background: #555;
        }

        .btn:focus {
            outline: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thông Tin Đặt Hàng</h1>
        <form action="checkout.php" method="POST">
            <div class="form-group">
                <label for="name">Họ và Tên</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="phone">Số Điện Thoại</label>
                <input type="text" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="address">Địa Chỉ</label>
                <input type="text" id="address" name="address" required>
            </div>
            <button type="submit" class="btn">Đặt Hàng</button>
        </form>
    </div>
</body>
</html>
